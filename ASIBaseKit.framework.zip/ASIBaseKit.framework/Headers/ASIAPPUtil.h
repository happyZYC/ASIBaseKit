//
//  ASIAPPUtil.h
//  DepartmentAPP
//
//  Created by yongchang zhao on 2025/5/8.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface ASIAPPUtil : NSObject

// App 信息
+ (NSString *)appVersion;
+ (NSString *)appBuildNumber;
+ (NSString *)appName;
+ (NSString *)bundleIdentifier;

/// 安装来源是否是TestFlight
+ (BOOL)isTestFlight;


@end

NS_ASSUME_NONNULL_END
